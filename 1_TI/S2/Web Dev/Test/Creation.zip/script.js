let TEmploye = [['abderrahmen','Myriam',2,new Date(1959,09,30)],
                ['Abbess'     ,'Jilani',1,new Date(1965,10,11)],
                ['SALEH'      ,'AHMED' ,1,new Date(1969,11,16)],
                ['BACHA'      ,'Jihen' ,2,new Date(1978,09,07)],
                ['SOLTANI'    ,'ASMA'  ,2,new Date(1991,00,26)],
                ['FARAH'      ,'Mourad',1,new Date(1973,05,04)]
               ]


function CreerMatricule() {
	const nom = document.f1.txtnom.value.trim().toUpperCase();
	const prenom = document.f1.txtprenom.value.trim().toLowerCase();
	const sexe = parseInt(document.f1.optsexe.value);
	const dateNaissance = new Date(document.f1.txtDDN.value);
  
	const asciiCodeNom = nom.charCodeAt(0);
	const asciiCodePrenom = prenom.charCodeAt(0);
	const moisNaissance = ('0' + (dateNaissance.getMonth() + 1)).slice(-2);
	const anneeNaissance = dateNaissance.getFullYear().toString().slice(-4);
	const codeSexe = (sexe === 2) ? '2' : '1';
  
	const matricule = `${asciiCodeNom}/${asciiCodePrenom}/${codeSexe}/${moisNaissance}/${anneeNaissance}`;
  
	document.f1.txtmat.value = matricule;
  }
  
  function ValiderCreation(txt) {
	const nom = document.f1.txtnom.value.trim();
	const prenom = document.f1.txtprenom.value.trim();
	const dateNaissance = document.f1.txtDDN.value;
  
	if (nom === '' || prenom === '' || dateNaissance === '') {
	  document.f1.btncreer.disabled = true;
	  document.f1.txtmat.value = '';
	  return;
	}
  
	document.f1.btncreer.disabled = false;
  }
  

  const RechercheSexe = (sexe) => {
	let resultat = "";
	let listeEmployes = [];
	TEmploye.forEach((employe) => {
	  if (employe[2] === sexe) {
		listeEmployes.push(`${employe[0]} ${employe[1]}`);
	  }
	});
	resultat = `La liste des employés de sexe ${sexe === 1 ? 'Masculin' : 'Féminin'} est : ${listeEmployes.join('/')}`;
	document.f1.txtresultat.value = resultat;
  }
  
  

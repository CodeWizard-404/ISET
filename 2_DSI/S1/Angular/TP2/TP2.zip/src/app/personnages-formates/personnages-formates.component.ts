import { Component } from '@angular/core';

@Component({
  selector: 'app-personnages-formates',
  templateUrl: './personnages-formates.component.html',
  styleUrls: ['./personnages-formates.component.css']
})
export class PersonnagesFormatesComponent {

}

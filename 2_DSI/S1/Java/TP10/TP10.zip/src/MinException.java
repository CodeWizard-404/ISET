class MinException extends Exception {
    public MinException(String message) {
        super(message);
    }
}
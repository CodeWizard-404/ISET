public class BaseDeFichiers {
    public static void main(String[] args) {
    }
}

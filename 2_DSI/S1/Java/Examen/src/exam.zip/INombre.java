interface INombre {
    int getNombreChansons();
}

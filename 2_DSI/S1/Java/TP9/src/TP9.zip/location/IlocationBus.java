package location;

public interface IlocationBus {
    double CoutLocation();
    double AssuranceParLocation();
}
